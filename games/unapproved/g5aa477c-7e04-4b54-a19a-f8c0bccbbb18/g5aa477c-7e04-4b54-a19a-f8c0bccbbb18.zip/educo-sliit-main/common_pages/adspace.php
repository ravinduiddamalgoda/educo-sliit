<?php
echo '<div class="adspace">asdasd</div>';
?>